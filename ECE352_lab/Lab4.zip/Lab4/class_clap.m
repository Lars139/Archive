%class_clap.m
%determining distance of slap using cross correlation and triangulation
close all

%importing data from class (the loud clap)
[data_B, Fs, nbits] = wavread('the_clap_left.wav');
[data_A, ~, ~] = wavread('the_clap_right.wav');

%listening to audio to find samples of clap to extract

%sound(data_A, Fs, nbits);
%sound(data_B, Fs, nbits);
figure
plot(data_B)
figure
plot(data_A)
found the best sample range for each site
A_ch1 = data_A(52900:53800, 1);
A_ch2 = data_A(52900:53800, 2);
B_ch1 = data_B(52500:53400, 1);
B_ch2 = data_B(52500:53400, 2);

[A_cor, ~, m_Apeak] = cross_corr(A_ch1, A_ch2);
[B_cor, m, m_Bpeak] = cross_corr(B_ch1, B_ch2);

%analyzing clap found in audio using cross correlation 
t_shift = (m/Fs)*10^3;  %see taxi_honk

figure
subplot(2,2,1); plot(t_shift, A_cor); 
title('Correlation of site A');xlabel('Time shift in ms');
subplot(2,2,2); plot(t_shift, B_cor); 
title('Correlation of site B');xlabel('Time shift in ms');
subplot(2,2,3); plot(t_shift, A_cor);
xlim([-1 1]);
title('Close up of correlation for site A');
xlabel('Time shift in ms');
subplot(2,2,4); plot(t_shift, B_cor);
xlim([-1 1]);
title('Close up of correlation for site B');
xlabel('Time shift in ms');

%measured distances (in feet)
d = 9.625/12; %distance from mic to mic
s = 4.75;     %distance from siteA to siteB

%calculating the incident angle for each site
theta_A = incident_angle(m_Apeak, Fs, d);
theta_B = incident_angle(m_Bpeak, Fs, d);

%calculating the location to source from each site
[dis_A, dis_B] = locate_src(theta_A, theta_B, s); %distances in ft