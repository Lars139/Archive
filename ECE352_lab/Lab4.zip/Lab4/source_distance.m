%finds the distance 






