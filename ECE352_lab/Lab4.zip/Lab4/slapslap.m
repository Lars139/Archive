%distance b/w microphone 24.5 cm (d)
%distnace from source to microphone (s) 149.5 cm
%mic vol = 20

